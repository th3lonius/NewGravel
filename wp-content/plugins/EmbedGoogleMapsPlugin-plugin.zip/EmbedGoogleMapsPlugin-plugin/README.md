EmbedGoogleMapsPlugin
=====================

A simple, lightweight plugin for adding custom Google Maps to your WordPress site

## Installation

Dependencies: Node, Grunt

```
$ npm install
$ grunt watch
```


